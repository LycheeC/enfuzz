from ..obs_base import ObsBase

ObsImitation = ObsBase