from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class TransactionOriginUse(Checker):

    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        self.list=[]
        self.path=[]
    def check(self, logger):
        find =False

        def get_taint(val):
            t = Taint(val)  # 初始污点
            taint_func = t.taint
            taint_func([ORIGIN])
            return t


        for i, log in enumerate(logger.logs):

            if log.op == ORIGIN:  
                print('find Origin') 
                print(log.stack)                    
                value = log.stack[2]
                print(value)
                # 定义初始污点和追踪函数
                T = get_taint(value)
                taint_func = T.taint

                for j in range(i, len(logger.logs)):
                    if logger.logs[j].op == JUMPI:
                        print('find JUMPI')
                        print(logger.logs[j].stack) 
                        if value in logger.logs[j].stack:
                            find=True
                            if find:
                                for log in logger.logs:
                                    path = log.path
                                    self.path.append(list(path.values()))     
                                print(type(path),"Paths:", self.path, "\n")
                                self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/BSD',self.path)
                            return True
                       

class Taint:
    def __init__(self, val):
        self.tainted = {val}
        self.trace = {}

    def taint(self, sources):
        for source in sources:
            try:
                if source in self.trace:
                    self.tainted |= self.trace[source]
                else:
                    self.trace[source] = self.tainted.copy()
            except TypeError:
                pass

    def is_tainted(self, var):
        for key in self.trace:
            if var in self.trace[key]:
                return True
        return var in self.tainted
