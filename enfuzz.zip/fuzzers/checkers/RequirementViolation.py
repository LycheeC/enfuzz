from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class RequirementViolation(Checker):
    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        
        self.tx_count = 0
        self.tx_count_dict = dict()
        for name in contract_manager.contract_dict:
            self.tx_count_dict[name] = 0

        self.addresses = []
        for contract in contract_manager.contract_dict.values():
            self.addresses += contract.addresses

        for account in account_manager.accounts:
            self.addresses.append(account.address) 
        
        
   
    def check(self, logger):
        contract = self.contract_manager[logger.tx.contract]
        self.tx_count += 1
        self.tx_count_dict[contract.name] += 1

        call_stack = []
        call_stack.append(contract.addresses[0])


        for i, log in enumerate(logger.logs):
            if call_stack[-1]  not in self.contract_manager.address_to_contract:
                if log.op == REVERT:
                    return True
        
