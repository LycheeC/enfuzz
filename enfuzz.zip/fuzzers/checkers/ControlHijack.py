from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class ControlHijack(Checker):
    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        super().__init__()
        self.list=[]
        self.path=[]
   
    def check(self, logger):
        find =False
        for log in logger.logs:
            if log.op == JUMP:
                for val in log.stack:
                    if val==0xdeadcafe:
                        find = True
                        if find:
                            for log in logger.logs:
                                path = log.path
                                self.path.append(list(path.values()))     
                            print(type(path),"Paths:", self.path, "\n")
                            self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/AW',self.path)
                        return True
