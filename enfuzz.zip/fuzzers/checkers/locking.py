from .checker import Checker
from ilf.ethereum.evm.contract import *

class Locking(Checker):

    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        self.list=[]
        self.path=[]
    def check(self, logger):
        can_send_ether = self.contract_manager[logger.tx.contract].can_send_ether
        can_receive_ether = self.contract_manager[logger.tx.contract].can_receive_ether

        return can_receive_ether and not can_send_ether and logger.contract_receive_ether
        for log in logger.logs:
            if log.op == DELEGATECALL:
                if can_receive_ether and not can_send_ether:

                    for log in logger.logs:
                        path = log.path
                        self.path.append(list(path.values()))     
                    print(type(path),"Paths:", self.path, "\n")
                    self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/LOCKING',self.path)
                    return True

def check(self, logger):
    can_send_ether = self.contract_manager[logger.tx.contract].can_send_ether
    can_receive_ether = self.contract_manager[logger.tx.contract].can_receive_ether

    if can_receive_ether and not can_send_ether and logger.contract_receive_ether:
        for log in logger.logs:
            if log.op == DELEGATECALL:
                for log in logger.logs:
                    path = log.path
                    self.path.append(list(path.values()))     
                print(type(path), "Paths:", self.path, "\n")
                self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/LOCKING', self.path)
                return True

    return False
