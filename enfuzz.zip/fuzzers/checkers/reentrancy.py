from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class Reentrancy(Checker):

    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        self.bugReason=[]
        self.path=[]
        self.allpath=[]
    def check(self, logger):
        find =False
        has_transfer = False
        change_state = False
        pc1, pc2 = -1, -1
        CallDepth=0
        recordBugReason=[]
        for log in logger.logs:
            if log.op == CALL and int(log.stack[-3], 16) > 0 and int(log.stack[-1], 16) > 0 :  # CALL: [gas  addr  value  argsOffset  argsLength  retOffset  retLength]             
                has_transfer = True
                pc1 = log.pc
                recordBugReason.append(log.pc)
                recordBugReason.append(log.op_name)
                recordBugReason.append(log.stack)
            if log.op == SSTORE :
                change_state = True
                pc2 = log.pc
                recordBugReason.append(log.pc)
                recordBugReason.append(log.op_name)
                recordBugReason.append(log.stack)
        pc_follow = ((pc1 != -1) and (pc2 != -1) and (pc1 < pc2))

        if has_transfer and change_state and pc_follow :
            find = True
      #      print("find is1111111111111111111111111111")
       #     print(log.stack)
     #       print('\n')
            if find:
                self.bugReason.extend(recordBugReason)
                print("BugReason:", recordBugReason, "\n")
                recordBugReason.clear()
                for log in logger.logs:
                    path = log.path
                    allpath=log.allpath
                    self.path.append(list(path.values())) 
                    self.allpath.append(allpath)      
             #   print(type(path),"Paths:", self.allpath, "\n")
             #  self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/RE',self.path)
                return True

