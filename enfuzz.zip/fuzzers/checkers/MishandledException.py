from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class MishandledException(Checker):

    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        self.list=[]
        self.path=[]
    def check(self, logger):
        find =False
        def get_taint(val):
            t = Taint(val)  # 初始污点
            taint_func = t.taint
            taint_func([CALL])
            return t
            
        for i, log in enumerate(logger.logs):
            if log.op == CALL:
                value = int(log.stack[-1], 16)
                t = get_taint(value)
                jumpto_index = None  # 存储应跳转到的指令索引
                for j in range(i, len(logger.logs)):
                    if logger.logs[j].op == JUMPI and t.is_tainted(logger.logs[j].stack[-2]):
                        jumpto_index = int(logger.logs[j].stack[-1], 16)
                        break
                if jumpto_index is not None:
                    # 检查跳转指令之后的指令中是否使用了返回值
                    used_return_value = False
                    for k in range(jumpto_index + 1, len(logger.logs)):
                        if logger.logs[k].op == JUMPDEST and t.is_tainted(logger.logs[k].stack[-1]):
                            used_return_value = True
                            break
                    if not used_return_value:
                        find = True
                        if find:
                            for log in logger.logs:
                                path = log.path
                                self.path.append(list(path.values()))     
                            print(type(path),"Paths:", self.path, "\n")
                            self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/ME',self.path)
                            return True
        return False
class Taint:
    def __init__(self, val):
        self.tainted = {val}
        self.trace = {}

    def taint(self, sources):
        for source in sources:
            try:
                if source in self.trace:
                    self.tainted |= self.trace[source]
                else:
                    self.trace[source] = self.tainted.copy()
            except TypeError:
                pass

    def is_tainted(self, var):
        for key in self.trace:
            if var in self.trace[key]:
                return True
        return var in self.tainted
