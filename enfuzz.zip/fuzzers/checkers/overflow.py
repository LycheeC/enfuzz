from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *
from ilf.ethereum.analysis import CFG

class overflow(Checker):

    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
	
  #   self.covered_pcs_dict = dict()
   #     for name in contract_manager.contract_dict:
    #        self.covered_pcs_dict[name] = set()
            

    def check(self, logger):
        for log in logger.logs:
            if log.op == ADD:
     #           print("add log.stack is")
      #          print(log.stack)
       #         print(int(log.stack[-1], 16)) 
        #        print(log.stack[-1]) 
         #       print(int(log.stack[0], 16))  
          #      print(log.stack[0])
                if ((int(log.stack[0], 16)+int(log.stack[1], 16)) > 0xffffffffffffffff):                 
                   

                    return True    
              
            if log.op == SUB:
                if (int(log.stack[0], 16)> 0xffffffffffffffff ) or (int(log.stack[0], 16))>((int(log.stack[0], 16))-(int(log.stack[0], 16))) : 
       #             print("sub log.stack is")
        #            print(log.stack)
         #           print(int(log.stack[-1], 16)) 
          #          print(int(log.stack[-2], 16))         
                    return True                
            if log.op == MUL: 
                if ((int(log.stack[0], 16)*(int(log.stack[1], 16))) > 0xffffffffffffffff): 
      #              print("MUL log.stack is")
       #             print(log.stack)
        #            print(int(log.stack[-1], 16)) 
         #           print(int(log.stack[-2], 16))                
                    return True
                
            if log.op == MOD :

                if ((int(log.stack[0], 16)%int(log.stack[1], 16))> 0xffffffffffffffff)or(int(log.stack[0], 16)> 0xffffffffffffffff):
          #          print("Mod log.stack is")
           #         print(log.stack)
            #        print(int(log.stack[-1], 16)) 
             #       print(int(log.stack[-2], 16))                 
                    return True  

            if log.op == DIV:
                if log.stack and len(log.stack) >= 3:
                    if int(log.stack[1], 16) == 0 or ((int(log.stack[0], 16))//(int(log.stack[1], 16))> 0xffffffffffffffff)or((int(log.stack[0], 16)) > 0xffffffffffffffff):
          #              print("div log.stack is")
           #             print(log.stack)
            #            print(int(log.stack[-1], 16)) 
             #           print(int(log.stack[-2], 16))  
                        return True
            

