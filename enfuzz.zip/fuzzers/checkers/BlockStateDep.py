
from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class BlockStateDep(Checker):

    def __init__(self):
        super().__init__()

    def check(self, logger):

        def get_taint(val):
            t = Taint(val)  # 初始污点
            taint_func = t.taint
            taint_func([COINBASE, TIMESTAMP, NUMBER, DIFFICULTY, GASLIMIT, BLOCKHASH])
            return t

        find = False
        # 检查日志中是否存在与块状态相关的操作
        for i, log in enumerate(logger.logs):
            # 获取与块状态相关的记录并设置污点
            if log.op in (COINBASE, TIMESTAMP, NUMBER, DIFFICULTY, GASLIMIT, BLOCKHASH):
                value = int(log.stack[-1], 16)
                # 定义初始污点和追踪函数
                T = get_taint(value)
                taint_func = T.taint
                # 从当前操作向下追踪污染的值传递路径（即污染值是否流入CALL或JUMPI的操作数中）
                for j in range(i, len(logger.logs)):
                    if logger.logs[j].op in (CALL, CALLCODE):
                        # 监视污染是否流入CALL的操作数（即方法参数）
                        taint_func(logger.logs[j].stack[-1]) 
                        if T.is_tainted(logger.logs[j].stack[-3]):
                            find = True
                            break
                    elif logger.logs[j].op == JUMPI:
                        # 监视污染是否流入JUMPI的操作数
                        taint_func(logger.logs[j].stack[-2])
                        if T.is_tainted(logger.logs[j].stack[-2]):
                            find = True
                            break
                    elif logger.logs[j].op == STOP or logger.logs[j].op == RETURN:
                        break

                    

                if find:
                    return True
        return False

class Taint:
    def __init__(self, val):
        self.tainted = {val}
        self.trace = {}

    def taint(self, sources):
        for source in sources:
            try:
                if source in self.trace:
                    self.tainted |= self.trace[source]
                else:
                    self.trace[source] = self.tainted.copy()
            except TypeError:
                pass

    def is_tainted(self, var):
        for key in self.trace:
            if var in self.trace[key]:
                return True
        return var in self.tainted
