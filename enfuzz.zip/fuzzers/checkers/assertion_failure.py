from .checker import Checker
from ...ethereum import *
from ilf.ethereum.evm.contract import *

class assertion_failure(Checker):
    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        
        self.tx_count = 0
        self.tx_count_dict = dict()
        for name in contract_manager.contract_dict:
            self.tx_count_dict[name] = 0
            
        self.addresses = []
        for contract in contract_manager.contract_dict.values():
            self.addresses += contract.addresses

        for account in account_manager.accounts:
            self.addresses.append(account.address) 
        self.list=[]
        self.path=[]
        
   
    def check(self, logger):
        contract = self.contract_manager[logger.tx.contract]
        self.tx_count += 1
        self.tx_count_dict[contract.name] += 1

        call_stack = []
        call_stack.append(contract.addresses[0])
        find =False
        for i, log in enumerate(logger.logs):
            if log.op == INVALID:
                print('find1111111111111111111111111111111111111111111')
                print('\n')
            if call_stack[-1] in self.contract_manager.address_to_contract:
                if log.op == INVALID:
                    find = True
                    if find:
                        for log in logger.logs:
                            path = log.path
                            self.path.append(list(path.values()))     
                        print(type(path),"Paths:", self.path, "\n")
                        self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/AF',self.path)
                        return True


