from .checker import Checker
from ilf.ethereum.evm.contract import *

class Leaking(Checker):

    def __init__(self, contract_manager, account_manager):
        super().__init__()
        self.contract_manager = contract_manager
        self.account_manager = account_manager
        self.list=[]
        self.path=[]
    def check(self, logger):
        find =False
        if 'leaking' in logger.bug_res:   
            find = True
            if find:
                for log in logger.logs:
                    path = log.path
                    self.path.append(list(path.values()))     
                print(type(path),"Paths:", self.path, "\n")
                self.contract_manager.dump('/home/fpx/go/src/ilf/CFG/LEAKING',self.path)
                return True
