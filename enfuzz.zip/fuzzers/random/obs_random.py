from ..obs_base import ObsBase

ObsRandom = ObsBase