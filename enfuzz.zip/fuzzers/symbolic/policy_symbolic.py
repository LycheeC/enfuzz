import abc
import math
import json
from collections import defaultdict
from collections import OrderedDict
import random
from ...execution import Tx
import z3
from ..policy_base import PolicyBase
from ...ethereum import SolType
from ...ethereum import Method
from ...symbolic.symbolic import constraints
from ...symbolic.symbolic import svm_utils
from ..random import policy_random
import logging
from copy import copy, deepcopy
import torch
import torch.nn as nn

class PolicySymbolic(PolicyBase):

    def __init__(self, execution, contract_manager, account_manager):
        super().__init__(execution, contract_manager, account_manager)

        self.policy_random = policy_random.PolicyRandom(execution, contract_manager, account_manager)
        self.last_picked_pc_traces = []

        self.tx_count = 0
       

    def select_tx(self, obs):
        self.tx_count += 1
        svm = obs.svm
        gstates = []
        for address in svm.fuzz_addresses:
            gstates.extend(svm.sym_call_address(address, svm.root_wstate))
        logging.info(f'found {len(gstates)} states')
        if self.tx_count<10:
      #      print('\n')
         #   print(self.tx_count)
            return self.get_best_tx(obs, svm, gstates)
        else:
            
            return self.twoget_best_tx(obs, svm, gstates)
            
    def get_best_tx(self, obs, svm, gstates):
        gain_to_gstates = defaultdict(list)
        re_gstates = defaultdict(list)
        target_opcode=[]
        eqFunc_opRE_list = []
        for gstate in gstates:
            pc_set = set(gstate.pc_trace)
            op_set =set(gstate.op_trace)
            
       #     print('gstate.self.mstate is 9999999999999999999999999999999999999999')
         #   print(gstate.wstate.trace )
            
            opRE=self.Recordop(obs.sym_stat, op_set )
            if opRE==True:
                
                opmethod_name = gstate.wstate.trace.split('.')[1].split('(')[0]
             #   print(opmethod_name)
                eqFunc_opRE_list.append(opmethod_name)
                
            gain =  (self.evaluate_pc_set_gain(obs.sym_stat, pc_set))+2*(self.evaluate_opcode_set_gain(obs.sym_stat, op_set ))

            gain_to_gstates[gain].append(gstate)

        one=True
        for gain in sorted(gain_to_gstates.keys(), key=lambda k: -k):
      
            if gain == 0:
                logging.info('No feasible gain')
                return None
            gstate = sorted(gain_to_gstates[gain], key=lambda g: len(g.pc_trace))[0]

            if (gstate.wstate.trace.split('.')[1].split('(')[0] in eqFunc_opRE_list and one == True):
               # print(gstate.wstate.trace.split('.')[1].split('(')[0])       
                re_gstates[gain].append(gstate)
                one ==False

        for gain in re_gstates.keys():
            for gstate in sorted(re_gstates[gain], key=lambda g: len(g.pc_trace)):
            
                if len(self.last_picked_pc_traces) and self.last_picked_pc_traces[-1] == gstate.pc_trace:
                    continue
                solver = self.get_state_solver(gstate)
                if solver is None:
                    continue
                model = solver.model()
                sender_value = model.eval(gstate.environment.sender).as_long()
                sender = svm.possible_caller_addresses.index(sender_value)
                amount = model.eval(gstate.environment.callvalue).as_long()
                method_name = gstate.wstate.trace.split('.')[1].split('(')[0]
                address = hex(gstate.environment.active_address)
                if address not in obs.contract_manager.address_to_contract:
                    raise Exception('unknown address')
                contract = obs.contract_manager.address_to_contract[address]
                timestamp = self._select_timestamp(obs)
                if method_name == 'fallback':
                    if Method.FALLBACK not in contract.abi.methods_by_name:
                        continue
                    method_name = Method.FALLBACK
                    self.add_pc_set_to_stat(obs.sym_stat, set(gstate.pc_trace))
                    logging.info(f'sending tx {method_name} {hex(sender_value)} {gain}')
                    return Tx(self, contract.name, address, method_name, bytes(), [], amount, sender, timestamp, True)
                method = contract.abi.methods_by_name[method_name]
                timestamp = model.eval(gstate.environment.timestamp).as_long()
                inputs = method.inputs
                arguments = []
                random_args = self.policy_random._select_arguments(contract, method, sender, obs)
                logging.info(f'sending tx {method.name} {hex(sender_value)} {gain}')
                for i, arg in enumerate(inputs):
                    using_random = False
                    t = arg.evm_type.t
                    
                    arg_eval = None
                    calldata = svm.sym_bv_generator.get_sym_bitvec(constraints.ConstraintType.CALLDATA,
                                                                gstate.wstate.gen,
                                                                index=4+i*32)
                    calldata_eval = model.eval(calldata)
                    if svm_utils.is_bv_concrete(calldata_eval):
                        arg_eval = calldata_eval.as_long()
                      #  initarg = arg_eval
                    else:
                        logging.debug(f'Using random variable for {method.name} {arg.name}')
                        using_random = True
                        arg_eval = random_args[i]
                       # initarg = arg_eval
                    if not using_random:
                        if t == SolType.AddressTy:
                            caller_constraint = z3.Or([calldata == p for p in svm.possible_caller_addresses if p != sender_value])
                            solver.add(caller_constraint)
                            if solver.check() == z3.sat:
                                calldata_eval = solver.model().eval(calldata)
                                arg_eval = calldata_eval.as_long()
                          #      initarg = arg_eval
                            arg_eval = hex(arg_eval % (2**160))
                        elif t == SolType.FixedBytesTy:
                            arg_eval = arg_eval % (8 * arg.evm_type.size)
                       #     initarg = arg_eval
                            arg_bytes = arg_eval.to_bytes(arg.evm_type.size, 'big')
                            arg_eval = [int(b) for b in arg_bytes]
                        elif t == SolType.ArrayTy:
                            arg_eval = random_args[i]
                      #      initarg = arg_eval
                        elif t == SolType.BoolTy:
                            arg_eval = False if arg_eval == 0 else True
                      #      initarg = arg_eval
                        elif t == SolType.StringTy:
                            size = random.randint(int(math.log(arg_eval) / math.log(8)) + 1, 40)
                            arg_eval = arg_eval.to_bytes(size, 'big')
                        #    initarg = arg_eval
                            arg_eval = bytearray([c % 128 for c in arg_eval]).decode('ascii')
                    if not isinstance(arg_eval, type(random_args[i])):
                        arg_eval = random_args[i]
                      #  initarg = arg_eval
                    arguments.append(arg_eval)
                self.add_pc_set_to_stat(obs.sym_stat, set(gstate.pc_trace))
                tx = Tx(self, contract.name, address, method.name, bytes(), arguments, amount, sender, timestamp, True)
               # print('11111111111contract.name:',contract.name, '   address:',address, '   method.name:',method.name, '   bytes():',bytes(), '   arguments:',arguments, '   amount',amount, '   sende:',sender, '   timestamp:',timestamp)

                return tx
        return None

    def twoget_best_tx(self, obs, svm, gstates):
        gain_to_gstates = defaultdict(list)
        re_gstates = defaultdict(list)
        target_opcode=[]
        eqFunc_opRE_list = []
        for gstate in gstates:
            pc_set = set(gstate.pc_trace)
            op_set =set(gstate.op_trace)
            
       #     print('gstate.self.mstate is 9999999999999999999999999999999999999999')
         #   print(gstate.wstate.trace )
            
            opRE=self.Recordop(obs.sym_stat, op_set )
            if opRE==True:
                
                opmethod_name = gstate.wstate.trace.split('.')[1].split('(')[0]
             #   print(opmethod_name)
                eqFunc_opRE_list.append(opmethod_name)
                
            gain =  (self.evaluate_pc_set_gain(obs.sym_stat, pc_set))+2*(self.evaluate_opcode_set_gain(obs.sym_stat, op_set ))

            gain_to_gstates[gain].append(gstate)

        one=True
        for gain in sorted(gain_to_gstates.keys(), key=lambda k: -k):
      
            if gain == 0:
                logging.info('No feasible gain')
                return None
            gstate = sorted(gain_to_gstates[gain], key=lambda g: len(g.pc_trace))[0]

            if (gstate.wstate.trace.split('.')[1].split('(')[0] in eqFunc_opRE_list and one == True):
            
                re_gstates[gain].append(gstate)
                one ==False
        for gain in sorted(gain_to_gstates.keys(), key=lambda k: -k):
            if gain == 0:
                continue
            for gstate in gain_to_gstates[gain]:
                re_gstates[gain].append(gstate)
        for gain in re_gstates.keys():
            for gstate in sorted(re_gstates[gain], key=lambda g: len(g.pc_trace)):
            
                if len(self.last_picked_pc_traces) and self.last_picked_pc_traces[-1] == gstate.pc_trace:
                    continue
                solver = self.get_state_solver(gstate)
                if solver is None:
                    continue
                model = solver.model()
                sender_value = model.eval(gstate.environment.sender).as_long()
                sender = svm.possible_caller_addresses.index(sender_value)
                amount = model.eval(gstate.environment.callvalue).as_long()
                method_name = gstate.wstate.trace.split('.')[1].split('(')[0]
                address = hex(gstate.environment.active_address)
                if address not in obs.contract_manager.address_to_contract:
                    raise Exception('unknown address')
                contract = obs.contract_manager.address_to_contract[address]
                timestamp = self._select_timestamp(obs)
                if method_name == 'fallback':
                    if Method.FALLBACK not in contract.abi.methods_by_name:
                        continue
                    method_name = Method.FALLBACK
                    self.add_pc_set_to_stat(obs.sym_stat, set(gstate.pc_trace))
                    logging.info(f'sending tx {method_name} {hex(sender_value)} {gain}')
                    return Tx(self, contract.name, address, method_name, bytes(), [], amount, sender, timestamp, True)
                method = contract.abi.methods_by_name[method_name]
                timestamp = model.eval(gstate.environment.timestamp).as_long()
                inputs = method.inputs
                arguments = []
                random_args = self.policy_random._select_arguments(contract, method, sender, obs)
                logging.info(f'sending tx {method.name} {hex(sender_value)} {gain}')
                for i, arg in enumerate(inputs):
                    using_random = False
                    t = arg.evm_type.t
                    
                    arg_eval = None
                    calldata = svm.sym_bv_generator.get_sym_bitvec(constraints.ConstraintType.CALLDATA,
                                                                gstate.wstate.gen,
                                                                index=4+i*32)
                    calldata_eval = model.eval(calldata)
                    if svm_utils.is_bv_concrete(calldata_eval):
                        arg_eval = calldata_eval.as_long()
                      #  initarg = arg_eval
                    else:
                        logging.debug(f'Using random variable for {method.name} {arg.name}')
                        using_random = True
                        arg_eval = random_args[i]
                       # initarg = arg_eval
                    if not using_random:
                        if t == SolType.AddressTy:
                            caller_constraint = z3.Or([calldata == p for p in svm.possible_caller_addresses if p != sender_value])
                            solver.add(caller_constraint)
                            if solver.check() == z3.sat:
                                calldata_eval = solver.model().eval(calldata)
                                arg_eval = calldata_eval.as_long()
                          #      initarg = arg_eval
                            arg_eval = hex(arg_eval % (2**160))
                        elif t == SolType.FixedBytesTy:
                            arg_eval = arg_eval % (8 * arg.evm_type.size)
                       #     initarg = arg_eval
                            arg_bytes = arg_eval.to_bytes(arg.evm_type.size, 'big')
                            arg_eval = [int(b) for b in arg_bytes]
                        elif t == SolType.ArrayTy:
                            arg_eval = random_args[i]
                      #      initarg = arg_eval
                        elif t == SolType.BoolTy:
                            arg_eval = False if arg_eval == 0 else True
                      #      initarg = arg_eval
                        elif t == SolType.StringTy:
                            size = random.randint(int(math.log(arg_eval) / math.log(8)) + 1, 40)
                            arg_eval = arg_eval.to_bytes(size, 'big')
                        #    initarg = arg_eval
                            arg_eval = bytearray([c % 128 for c in arg_eval]).decode('ascii')
                    if not isinstance(arg_eval, type(random_args[i])):
                        arg_eval = random_args[i]
                      #  initarg = arg_eval
                    arguments.append(arg_eval)
                self.add_pc_set_to_stat(obs.sym_stat, set(gstate.pc_trace))
                tx = Tx(self, contract.name, address, method.name, bytes(), arguments, amount, sender, timestamp, True)
              #  print('11111111111contract.name:',contract.name, '   address:',address, '   method.name:',method.name, '   bytes():',bytes(), '   arguments:',arguments, '   amount',amount, '   sende:',sender, '   timestamp:',timestamp)

                return tx
        return None

    @staticmethod
    def add_pc_set_to_stat(stat, pc_set):
        for contract_name, pc in pc_set:
            stat.covered_pcs_dict[contract_name].add(pc)


    @staticmethod
    def evaluate_pc_set_gain(stat, pc_set):
        covered_pcs_dict = deepcopy(stat.covered_pcs_dict)
        for contract_name, pc in pc_set:
            covered_pcs_dict[contract_name].add(pc)
        total_coverage = 0
        stat_total_coverage = 0
        for contract_name, coverages in covered_pcs_dict.items():
            total_coverage += len(coverages)
        for contract_name, coverages in stat.covered_pcs_dict.items():
            stat_total_coverage += len(coverages)
        return total_coverage - stat_total_coverage


    @staticmethod
    def evaluate_opcode_set_gain(stat, op_set):
        allopcode = 0
        op = []
        covered_pcs_dict = deepcopy(stat.covered_pcs_dict)
        opcodes = ['EQ', 'SHA3', 'SELFDESTRUCT', 'SLOAD', 'SSTORE', 'COINBASE', 'TIMESTAMP', 'NUMBER', 'DIFFICULTY', 'GASLIMIT', 'BLOCKHASH', 'JUMP', 'JUMPI', 'CALL']
        num_opcodes = len(opcodes)
        input_size = 10  # 假设每个操作码的表示向量维度为10
        opcode_sequence = [opcode[1] for opcode in op_set]

        # 创建操作码到索引的映射
        opcode_to_index = {opcode: i for i, opcode in enumerate(opcodes)}

        # 创建操作码编码器
        encoder = OpcodeEncoder(num_opcodes, hidden_size=20)  # 隐藏状态的维度为20

        # 将操作码序列转换为对应的索引序列
        index_sequence = [opcode_to_index[opcode] for opcode in opcode_sequence if opcode in opcode_to_index]

        if len(index_sequence) == 0:
            # 如果没有匹配的操作码，则直接返回0
            return allopcode

        # 将索引序列转换为张量
        opcode_tensor = torch.tensor(index_sequence).long().unsqueeze(0)

        # 将操作码张量作为输入传递给操作码编码器
        attention_weights = encoder(opcode_tensor)

        # 打印注意力权重
        for i, opcode in enumerate(opcode_sequence):
            if opcode in opcode_to_index:
                opcode_index = opcode_to_index[opcode]
                attention_weight = attention_weights[0, opcode_index].item()
                allopcode += attention_weight
       # print(allopcode)
        return allopcode*10

    @staticmethod
    def get_state_solver(gstate):
        solver = z3.Solver()
        solver.set('timeout',  3 * 60 * 1000)
        solver.add(gstate.wstate.constraints)
        res = solver.check()
        if res == z3.unknown: logging.info(f'{gstate.wstate.trace} gstate check timeout')
        return solver if res == z3.sat else None
        
    @staticmethod
    def RecordFunc(stat, op_set):
        allopcode=0
        op=[]
        covered_pcs_dict = deepcopy(stat.covered_pcs_dict)
     #   print('op_set')
      #  print(op_set)
        for i,j in op_set:
            if j in ['EQ']:
                allopcode += 1
        return allopcode

    @staticmethod
    def Recordop(stat, op_set):
        required_opcodes = ['COINBASE', 'TIMESTAMP', 'NUMBER', 'DIFFICULTY', 'GASLIMIT', 'BLOCKHASH']
        optional_opcodes = ['CREATE', 'CALL', 'CALLCODE']


        has_required_opcodes = any(j in required_opcodes for _, j in op_set)
        has_optional_opcodes = any(j in optional_opcodes for _, j in op_set)
        
        has_call_opcodes = any(j == 'CALL' for _, j in op_set)
        has_invalid_opcode = any(j == 'INVALID' for _, j in op_set)
       # has_sstore_opcode = any(j == 'SSTORE' for _, j in op_set)
        has_delegatecall_opcode = any(j == 'DELEGATECALL' for _, j in op_set)
        has_selfdestruct_opcode = any(j == 'SELFDESTRUCT' for _, j in op_set)
        has_revert_opcode = any(j == 'REVERT' for _, j in op_set)
        if has_required_opcodes and has_optional_opcodes:
            return True
        if has_call_opcodes:
            return True
        if has_invalid_opcode:
            return True
    #    if has_sstore_opcode:
     #       return True 
        if has_delegatecall_opcode:
            return True  
        if has_selfdestruct_opcode:
            return True  
        if has_revert_opcode:
            return True  
        else:
            return False
        
        
        
class Attention(nn.Module):
    def __init__(self, input_size):
        super(Attention, self).__init__()
        self.input_size = input_size
        self.opcode_embeddings = nn.Embedding(input_size, input_size)
        self.attention_weights = nn.Linear(input_size, 1)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, opcodes):
        opcode_embeddings = self.opcode_embeddings(opcodes)
        attention_scores = self.attention_weights(opcode_embeddings)
        attention_weights = self.softmax(attention_scores)
        return attention_weights

class OpcodeEncoder(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(OpcodeEncoder, self).__init__()
        self.hidden_size = hidden_size
        self.opcode_embeddings = nn.Embedding(input_size, input_size)
        self.lstm = nn.LSTM(input_size, hidden_size, bidirectional=True)
        self.attention = LocalGatedAttention(hidden_size*2)  # 使用Bi-LSTM的双向输出作为局部门控注意力的输入

    def forward(self, opcodes):
        opcode_embeddings = self.opcode_embeddings(opcodes)
        opcode_embeddings = opcode_embeddings.permute(1, 0, 2)  
        _, (hidden, _) = self.lstm(opcode_embeddings)
        hidden = torch.cat((hidden[-2], hidden[-1]), dim=1)  # 将前向和后向的隐藏状态拼接
        attention_weights = self.attention(hidden)
        return attention_weights


class LocalGatedAttention(nn.Module):
    def __init__(self, hidden_size):
        super(LocalGatedAttention, self).__init__()
        self.hidden_size = hidden_size
        self.opcode_weights = nn.Linear(hidden_size, hidden_size)
        self.gate_weights = nn.Linear(hidden_size, hidden_size)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, hidden_states):
        opcode_scores = self.opcode_weights(hidden_states)
        gate_scores = self.gate_weights(hidden_states)
        attention_logits = opcode_scores + gate_scores
        attention_weights = self.softmax(attention_logits)
        return attention_weights
