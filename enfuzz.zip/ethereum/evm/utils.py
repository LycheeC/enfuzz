try:
    from Crypto.Hash import keccak
    import hashlib

    def sha3_256(x): return keccak.new(digest_bits=256, data=x).digest()
except (ImportError, ModuleNotFoundError):
    import sha3 as _sha3

    def sha3_256(x): return _sha3.keccak_256(x).digest()


TT256 = 2 ** 256
TT256M1 = 2 ** 256 - 1
TT255 = 2 ** 255
SECP256K1P = 2**256 - 4294968273

#它将一个无符号整数转换为有符号整数。如果输入的整数小于2^255，则返回原始值；否则，返回原始值减去2^256。
def to_signed(i):
    return i if i < TT255 else i - TT256

#将一个字节数组转换为一个整数。
def bytes_to_int(value):
    return int.from_bytes(value, byteorder='big')

#将一个整数编码为一个32字节的大端字节序列，并返回一个列表
def encode_int32(v):
    return list(v.to_bytes(32, byteorder='big'))

#它将一个整数转换为大端字节序列。
def int_to_big_endian(value: int):
    return value.to_bytes((value.bit_length() + 7) // 8 or 1, "big")

#将一个大端字节序列转换为整数。
def big_endian_to_int(value: bytes):
    return int.from_bytes(value, "big")

#它接受一个参数seed，并返回一个256位的keccak哈希值。
def sha3(seed):
    return sha3_256(to_string(seed))

#它将输入的值转换为字节数组。
# 如果输入是字节数组，则直接返回；
# 如果输入是字符串，则将其转换为字节数组；
# 如果输入是整数，则将其转换为字符串，再将其转换为字节数组。
def to_string(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return bytes(value, 'utf-8')
    if isinstance(value, int):
        return bytes(str(value), 'utf-8')
    else:
    	return None   
