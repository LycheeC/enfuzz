import z3

class KeccakManager:
    def __init__(self):
